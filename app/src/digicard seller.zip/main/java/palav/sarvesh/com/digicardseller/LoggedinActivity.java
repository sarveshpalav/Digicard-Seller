package palav.sarvesh.com.digicardseller;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.HashMap;

/**
 * Created by sarveshpalav on 24/12/16.
 */
public class LoggedinActivity extends AppCompatActivity {
EditText Bill;
    Button Generate;

    String bill,generate;
    SharedPreferences sharedpreferences;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
setContentView(R.layout.activity_loggedin);

        sharedpreferences = getSharedPreferences(CONFIG.MyPREFERENCES, Context.MODE_PRIVATE);

        Bill =(EditText)findViewById(R.id.bill);
        Generate =(Button)findViewById(R.id.generate);

        Generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              bill = Bill.getText().toString().trim();
                generate = Generate.getText().toString().trim();
                generate(bill);

            }
        });
    }

    public void generate(String bill)
    {
        class generate extends AsyncTask<String,String,String>
        {

            @Override
            protected void onPostExecute(String s) {

                super.onPostExecute(s);

                Intent i = new Intent(LoggedinActivity.this,QRPage.class);
                i.putExtra("otp",s);
                startActivity(i);
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected String doInBackground(String... params) {
                String bill = params[0];
                String cardid = sharedpreferences.getString(CONFIG.sharedprefcardid,"");
                String cardname = sharedpreferences.getString(CONFIG.sharedprefcardname,"");
                System.out.println("ello"+cardname);
                String sellerid = sharedpreferences.getString(CONFIG.sharedprefsellerid,"");

                HashMap<String, String> data = new HashMap<String,String>();
                data.put("bill",bill);
                data.put("cardid",cardid);
                data.put("cardname",cardname);
                data.put("sellerid",sellerid);


                RequestHandler ruc = new RequestHandler();
            String result =    ruc.sendPostRequest(CONFIG.INSERT_TRANS,data);
System.out.println("Pranal");
                System.out.println("Sid"+result);


                return result;
            }
        }
        generate generate = new generate();
        generate.execute(bill);
    }



}
