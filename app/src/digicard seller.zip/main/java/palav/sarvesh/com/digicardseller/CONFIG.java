package palav.sarvesh.com.digicardseller;

/**
 * Created by sarveshpalav on 24/12/16.
 */
public class CONFIG {



    public static String REGISTER_URL="";
    public static String LOGIN_URL="https://digicard.000webhostapp.com/loginandroidseller.php";
    public static String GET_USERINFO="https://digicard.000webhostapp.com/getting_seller_info.php";
    public static  String INSERT_TRANS="https://digicard.000webhostapp.com/Seller_Transaction.php";
    public static  String STATUS="https://digicard.000webhostapp.com/checkseller.php";




    public static String sharedprefsellerid ="id";
    public static String sharedprefselleremail="email";
    public static String sharedprefsellerphone="phone";
    public static String sharedprefsellername="name";
    public static String sharedprfisloggedin="islogin";
    public static String sharedprefcardid="cardid";
    public static String sharedprefcardname="cardname";
    public static final String MyPREFERENCES = "digicarseller" ;
}
